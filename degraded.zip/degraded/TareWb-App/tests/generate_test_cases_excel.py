"""Generate Tare WB QA test cases as Excel (.xlsx) and CSV."""

from __future__ import annotations

import csv
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parent.parent
DOCS = ROOT / "docs"
OUT_XLSX = DOCS / "Tare_WB_Test_Cases.xlsx"
OUT_CSV = DOCS / "Tare_WB_Test_Cases.csv"

HEADERS = [
    "TC_ID",
    "Module",
    "Category",
    "Title",
    "Preconditions",
    "Steps",
    "Test_Data",
    "Expected_Result",
    "Priority",
    "Type",
    "Automation",
]

# Automation: Automated = covered by unittest; Manual = field/QA; Both = either
ROWS = [
    # ------------------------------------------------------------------ API
    ["TC-API-001", "API", "Health", "Root health check", "App running", "1. GET /", "None", "HTTP 200; service identifies Tare WB; status running", "P1", "Positive", "Manual"],
    ["TC-API-002", "API", "Status", "GET /api/status while IDLE", "App IDLE", "1. GET /api/status", "None", "HTTP 200; state=IDLE; wb_type; hardware/txn snapshot", "P1", "Positive", "Manual"],
    ["TC-API-003", "API", "Reset", "Force reset to IDLE", "Any state", "1. POST /api/reset", "None", "HTTP 200; IDLE; entry green/open exit red/closed; RFID stopped", "P1", "Positive", "Manual"],
    ["TC-API-004", "API", "Simulate", "Simulate entry sensor (demo)", "DEMO_MODE=true; IDLE", "1. POST /api/simulate-entry", "None", "HTTP 200; VEHICLE_POSITIONING; direction ENTRY_A (uni/bi)", "P2", "Positive", "Manual"],
    ["TC-API-005", "API", "Simulate", "Simulate WB sensor (demo)", "DEMO_MODE; VEHICLE_POSITIONING", "1. POST /api/simulate-wb", "None", "HTTP 200; WEIGHT_CAPTURE then weight path", "P2", "Positive", "Manual"],
    ["TC-API-006", "API", "Simulate", "Simulate exit sensor (demo)", "DEMO_MODE; EXIT_GRANTED", "1. POST /api/simulate-exit", "None", "HTTP 200; crossing complete; IDLE after delay boom close", "P2", "Positive", "Manual"],
    # ------------------------------------------------------------------ Sensor / Flow start
    ["TC-SEN-001", "Sensor", "Entry", "Entry sensor starts ENTRY_A cycle", "IDLE; uni or bi", "1. Entry DI rising edge", "entry occupied", "State VEHICLE_POSITIONING; direction=ENTRY_A; MOVE FORWARD; RFID not started", "P0", "Positive", "Automated"],
    ["TC-SEN-002", "Sensor", "WB", "WB sensor starts weighing", "VEHICLE_POSITIONING", "1. WB sensor occupied", "wb pin TRUE", "WEIGHT_CAPTURE; entry TL red boom closed; digitizer called", "P0", "Positive", "Manual"],
    ["TC-SEN-003", "Sensor", "Exit", "Exit sensor while IDLE ignored (uni)", "Unidirectional IDLE", "1. Exit sensor occupied", "exit TRUE", "Stay IDLE; no ENTRY_B; no RFID start", "P1", "Negative", "Automated"],
    ["TC-SEN-004", "Sensor", "Exit", "Exit clears ENTRY_A after grant", "EXIT_GRANTED; ENTRY_A", "1. Exit sensor occupied", "exit TRUE", "Force IDLE; exit boom close delayed 10s", "P0", "Positive", "Automated"],
    ["TC-SEN-005", "Sensor", "Timeout", "Positioning timeout resets IDLE", "VEHICLE_POSITIONING; no WB", "1. Wait POSITIONING_SEC", "120s default", "IDLE; entry green/open", "P1", "Positive", "Manual"],
    ["TC-SEN-006", "Sensor", "Timeout", "Weight capture timeout resets IDLE", "WEIGHT_CAPTURE; digitizer hang", "1. Wait WEIGHT_CAPTURE_SEC", "60s default", "IDLE", "P1", "Positive", "Manual"],
    ["TC-SEN-007", "Sensor", "Timeout", "Exit wait timeout resets IDLE", "EXIT_GRANTED; no exit sensor", "1. Wait EXIT_WAIT_SEC", "120s", "IDLE; boom close immediate on timeout", "P1", "Positive", "Automated"],
    # ------------------------------------------------------------------ Digitizer / Weight
    ["TC-WT-001", "Digitizer", "Stable weight", "Weight > 5 t continues to RFID", "WEIGHT_CAPTURE; digitizer OK", "1. Digitizer returns weight > 5000 kg", "e.g. 12500", "WEIGHT_OK → RFID_READ; RFID login/mode/start for selected direction", "P0", "Positive", "Manual"],
    ["TC-WT-002", "Digitizer", "Low weight", "Weight ≤ 5 t resets IDLE", "WEIGHT_CAPTURE", "1. Digitizer returns ≤ 5000 kg", "e.g. 3000", "WEIGHT_LOW; IDLE; RFID never started", "P0", "Negative", "Manual"],
    ["TC-WT-003", "Digitizer", "Fail", "Digitizer fail resets IDLE", "WEIGHT_CAPTURE", "1. Digitizer ok=false or no weight", '{"ok":false}', "WEIGHT_FAIL; digitizer_error voice; IDLE", "P0", "Negative", "Manual"],
    ["TC-WT-004", "Digitizer", "Demo", "Demo digitizer returns fixed weight", "DEMO_MODE=true", "1. Call read_stable_weight", "demo 12500", "ok=true weight=12500.0", "P2", "Positive", "Automated"],
    ["TC-WT-005", "Digitizer", "HTTP", "Calls digitizer-app /read_stable_weight", "Real digitizer PC", "1. Capture HTTP from Tare WB", "host:port from config", "POST /read_stable_weight; not local COM", "P1", "Positive", "Manual"],
    ["TC-WT-006", "Digitizer", "Final weight", "Final weight after ANPR path", "After ANPR 0/1 continue", "1. Final digitizer read 2. weight_details", "current weight", "Final weight announced (tare); weight_details posted; no VNO announce", "P0", "Positive", "Manual"],
    # ------------------------------------------------------------------ RFID
    ["TC-RFID-001", "RFID", "Boot", "No RFID login/mode/start at boot", "App start", "1. Start main.py 2. Watch logs", "API RFID configured", "No cloud login/mode/start until weight OK; RFID idle at boot", "P0", "Positive", "Manual"],
    ["TC-RFID-002", "RFID", "Boot", "No RFID start on entry sensor", "IDLE → entry occupied", "1. Entry edge", "ENTRY_A", "Direction set; prepare_idle NOT called", "P0", "Positive", "Automated"],
    ["TC-RFID-003", "RFID", "Start", "RFID starts only after weight OK", "Weight > min", "1. Complete weighing OK", "weight>5000", "login→mode→start for active direction", "P0", "Positive", "Automated"],
    ["TC-RFID-004", "RFID", "Stop", "RFID stops immediately on first tag", "RFID_READ scanning", "1. POST /rfid_data with tags", "Valid idHex", "cloud/stop before OCI validate; no duplicate scans", "P0", "Positive", "Automated"],
    ["TC-RFID-005", "RFID", "Reader API", "Accept Zebra tags on /rfid_data", "RFID_READ awaiting", "1. POST /rfid_data", "Zebra TAG list", "HTTP 200; validation cycle starts", "P0", "Positive", "Manual"],
    ["TC-RFID-006", "RFID", "Reader API", "Reject empty tags", "RFID_READ", "1. POST /rfid_data []", "[]", "HTTP 400 or ignore empty", "P1", "Negative", "Manual"],
    ["TC-RFID-007", "RFID", "Ignore", "Ignore tags outside RFID_READ", "IDLE or POSITIONING", "1. POST /rfid_data", "Valid tags", "Ignored / buffered only in POSITIONING/WEIGHT if early; no OCI", "P1", "Negative", "Automated"],
    ["TC-RFID-008", "RFID", "Validate", "OCI RFID validate success", "RFID_READ; OCI up", "1. Tag accepted 2. OCI 200 truck_details", "T|rfid|veh|...|token|ip", "vehicle_no/token parsed; proceed ANPR", "P0", "Positive", "Manual"],
    ["TC-RFID-009", "RFID", "Validate", "OCI RFID validate failure", "RFID_READ", "1. OCI fail / no slip", "status != 200", "RFID error path; exit grant or error display per flow", "P0", "Positive", "Manual"],
    ["TC-RFID-010", "RFID", "Payload", "RFID validate body fields", "Any validate call", "1. Capture request", "rfid + device_ip", "JSON has rfid and device_ip", "P1", "Positive", "Manual"],
    ["TC-RFID-011", "RFID", "Mobile", "Handheld RFID during RFID_READ", "RFID_READ", "1. POST /rfid_data_from_mobile_app", '{"rfid_data":"..."}', "OCI validate; continue or error like fixed reader", "P1", "Positive", "Manual"],
    ["TC-RFID-012", "RFID", "Cloud", "API mode no TCP 5555 client", "mode=API", "1. Start app", "Zebra API", "No TCP CLIENT to 5555; tags via HTTP", "P0", "Positive", "Manual"],
    # ------------------------------------------------------------------ Bidirectional
    ["TC-BI-001", "Bidirectional", "ENTRY_A", "Entry sensor selects ENTRY_A", "wb_type=bidirectional; IDLE", "1. Entry occupied", "ENTRY_A", "direction=ENTRY_A; RFID not started yet", "P0", "Positive", "Automated"],
    ["TC-BI-002", "Bidirectional", "ENTRY_B", "Exit sensor selects ENTRY_B while IDLE", "bidirectional IDLE", "1. Exit occupied", "ENTRY_B", "direction=ENTRY_B; RFID not started", "P0", "Positive", "Automated"],
    ["TC-BI-003", "Bidirectional", "RFID", "Weight OK starts entry_b reader for ENTRY_B", "ENTRY_B; weight OK", "1. Digitizer >5t", "entry_b cloud", "entry_b prepare_idle; entry_a not started", "P0", "Positive", "Automated"],
    ["TC-BI-004", "Bidirectional", "Crossing", "ENTRY_B completes on entry sensor", "EXIT_GRANTED ENTRY_B", "1. Entry occupied", "ENTRY_B", "Reset IDLE; boom delay close", "P0", "Positive", "Automated"],
    ["TC-BI-005", "Bidirectional", "Crossing", "ENTRY_B exit sensor does not complete", "EXIT_GRANTED ENTRY_B", "1. Exit occupied again", "same side", "Stay EXIT_GRANTED; no IDLE", "P1", "Negative", "Automated"],
    ["TC-BI-006", "Bidirectional", "Config", "rfid_configs returns both readers", "bi config", "1. settings.rfid_configs()", "entry_a + entry_b", "Both direction keys present", "P1", "Positive", "Automated"],
    ["TC-BI-007", "Bidirectional", "Opposite", "Opposite reader stopped before start", "Weight OK; prior other side", "1. Start selected reader", "two clouds", "Opposite login/stop then selected prepare_idle", "P1", "Positive", "Manual"],
    # ------------------------------------------------------------------ ANPR
    ["TC-ANPR-001", "ANPR", "Detect", "anpr_status=1 happy path", "RFID valid", "1. ANPR returns anpr_status=1", '{"anpr_status":1}', "Top photo; invalid-truck; final weight; weight_details; boom-close(truck_details); EXIT_GRANTED", "P0", "Positive", "Automated"],
    ["TC-ANPR-002", "ANPR", "Detect", "anpr_status=0 enters status_check loop", "RFID valid", "1. ANPR returns anpr_status=0", '{"anpr_status":0}', "Top photo; invalid-truck; MANUAL_UPDATE; poll status_check every 5s", "P0", "Positive", "Automated"],
    ["TC-ANPR-003", "ANPR", "Detect", "anpr_status=2 enters status_check loop", "RFID valid", "1. ANPR returns anpr_status=2", '{"anpr_status":2}', "Top photo; invalid-truck; MANUAL_UPDATE; poll status_check every 5s (same as status 0)", "P0", "Positive", "Automated"],
    ["TC-ANPR-004", "ANPR", "Payload", "ANPR request key token (not token_no)", "RFID valid with token", "1. Capture ANPR POST body", "vehicle_number rfid token device_ip", "JSON key is token; no token_no key", "P0", "Positive", "Manual"],
    ["TC-ANPR-005", "ANPR", "Payload", "ANPR required fields", "Any ANPR call", "1. Inspect POST", "vehicle_number + rfid", "Both always present; token/device_ip if available", "P1", "Positive", "Manual"],
    ["TC-ANPR-006", "ANPR", "Auth", "ANPR uses separate host and auth", "anpr_detect_url set", "1. Trigger ANPR", "ANPR_BASE_URL", "POST to ANPR host; Basic Auth anpr credentials", "P1", "Positive", "Manual"],
    ["TC-ANPR-007", "ANPR", "Normalize", "anpr_status normalization", "Various ANPR bodies", "1. Unit/parse responses", "anpr_status / best_match", "Status 0/1/2 normalized correctly", "P1", "Positive", "Automated"],
    # ------------------------------------------------------------------ status_check / Manual
    ["TC-MAN-001", "Manual", "status_check", "Retry every 5 seconds", "anpr_status=0", "1. Observe poll interval", "TRUCK_ANPR_RETRY_TIMER=5", "status_check called every ~5s", "P0", "Positive", "Manual"],
    ["TC-MAN-002", "Manual", "status_check", "vehicleStatus=1 continues flow", "MANUAL_UPDATE", "1. Response vehicleStatus 1", '{"vehicleStatus":1}', "Continue final weight → weight_details → boom-close → exit", "P0", "Positive", "Automated"],
    ["TC-MAN-003", "Manual", "status_check", "vehicleStatus=0 keeps polling", "MANUAL_UPDATE", "1. Response vehicleStatus 0", '{"vehicleStatus":0}', "Stay in loop; retry after 5s", "P1", "Positive", "Manual"],
    ["TC-MAN-004", "Manual", "status_check", "vehicleStatus=2 aborts to exit", "MANUAL_UPDATE", "1. Response vehicleStatus 2", '{"vehicleStatus":2}', "Abort; EXIT_GRANTED path; no weight_details", "P0", "Positive", "Manual"],
    ["TC-MAN-005", "Manual", "status_check", "HTTP 200 without vehicleStatus does not continue", "MANUAL_UPDATE", "1. Response statusCode 200 only", '{"statusCode":200}', "Treat as retry (status 0); wait for vehicleStatus=1", "P0", "Negative", "Automated"],
    ["TC-MAN-006", "Manual", "Payload", "status_check four fields", "Manual loop", "1. Capture POST body", "vehicleNo_web vehicleNo_anpr rfid device_ip", "All four fields present", "P1", "Positive", "Automated"],
    # ------------------------------------------------------------------ Camera / Images
    ["TC-CAM-001", "Camera", "Top photo", "Capture after ANPR 0/1", "Top RTSP configured; ANPR 0 or 1", "1. Complete ANPR branch", "RTSP URL", "JPEG under images/; name TOKEN_dd-mm-yy-HH-MM-SS_TRUCK_PCIP_TOP.jpg", "P0", "Positive", "Automated"],
    ["TC-CAM-002", "Camera", "Naming", "Filename shape with token truck IP", "Known token/truck/IP", "1. build_top_photo_filename", "TRIP + OD05 + IP", "Matches {TOKEN}_{ts}_{TRUCK}_{IP}_TOP.jpg", "P1", "Positive", "Automated"],
    ["TC-CAM-003", "Camera", "Naming", "Sanitize unsafe filename chars", "Token/truck with / * space", "1. build_top_photo_filename", "unsafe chars", "Replaced with underscore", "P2", "Positive", "Automated"],
    ["TC-CAM-004", "Camera", "RTSP", "Capture fail uses error.jpg", "RTSP missing or capture exception", "1. ANPR 0/1 path", "fail capture", "top_image=error.jpg sent to invalid-truck / weight_details", "P0", "Negative", "Automated"],
    ["TC-CAM-005", "Camera", "Config", "Front RTSP configured but not captured", "Both cameras in iot config", "1. Run ANPR path", "front URL saved", "Only top captured; front name from ANPR response if any", "P1", "Positive", "Manual"],
    ["TC-CAM-006", "Camera", "API", "top_image sent on invalid-truck", "ANPR 0/1", "1. Capture invalid-truck body", "top filename", "payload.top_image = TOP.jpg name", "P0", "Positive", "Automated"],
    ["TC-CAM-007", "Camera", "API", "top_image_name on weight_details", "After final weight", "1. Capture weight_details", "top/front/anpr names", "top_image_name front_image_name anpr_image_name present", "P0", "Positive", "Automated"],
    # ------------------------------------------------------------------ Boom / Hardware
    ["TC-BOOM-001", "Hardware", "Idle", "IDLE: entry green/open exit red/closed", "Boot or reset", "1. Observe TL/booms", "Idle", "Entry green+open; exit red+closed", "P0", "Positive", "Manual"],
    ["TC-BOOM-002", "Hardware", "Weigh", "WB occupied closes entry", "POSITIONING → WB", "1. WB edge", "weigh start", "Entry red + boom closed", "P0", "Positive", "Manual"],
    ["TC-BOOM-003", "Hardware", "Exit", "EXIT_GRANTED opens exit", "After weight_details path", "1. Enter exit granted", "exit hardware", "Exit green + boom open; MOVE FORWARD", "P0", "Positive", "Manual"],
    ["TC-BOOM-004", "Hardware", "Delay", "Exit boom closes 10s after crossing", "EXIT sensor after grant", "1. Exit occupied 2. Watch boom", "BOOM_CLOSE_DELAY_SEC=10", "IDLE immediately; boom.close after 10s", "P0", "Positive", "Automated"],
    ["TC-BOOM-005", "Hardware", "Delay", "Timeout reset closes boom immediately", "Force/timeout reset", "1. force_reset without delay", "timeout", "exit boom.close immediate; no 10s wait", "P1", "Positive", "Automated"],
    ["TC-BOOM-006", "Hardware", "boom-close API", "Post-weight boom-close uses truck_details", "ANPR 1 or manual 1", "1. Capture boom-close POST", "truck_details only", "Body {truck_details: current T|...}", "P0", "Positive", "Automated"],
    ["TC-BOOM-007", "Hardware", "Modbus", "Real Modbus TCP connect", "DEMO_MODE=false; I/O up", "1. Start app", "host:502", "ModbusTCP connected; not DemoIO", "P0", "Positive", "Manual"],
    ["TC-BOOM-008", "Hardware", "Modbus", "DEMO_MODE uses DemoIO", "DEMO_MODE=true", "1. Start app", "demo", "DemoIOController; simulate APIs work", "P2", "Positive", "Manual"],
    # ------------------------------------------------------------------ OCI payloads / Logging
    ["TC-OCI-001", "OCI", "Logging", "API exchange log format", "Any OCI/ANPR call", "1. Read app log", "URL Payload Response", "Separator lines with URL/Payload/Response JSON", "P2", "Positive", "Manual"],
    ["TC-OCI-002", "OCI", "invalid-truck", "Payload includes ANPR fields + top_image", "ANPR 0/1", "1. Capture body", "vehicleNo_web/anpr rfid images score status token device_ip top_image", "Matches builder contract", "P0", "Positive", "Automated"],
    ["TC-OCI-003", "OCI", "weight-details", "Weight details shape", "Final weight OK", "1. Capture body", "current_weight truck_details image names", "All required keys present", "P0", "Positive", "Automated"],
    ["TC-OCI-004", "OCI", "Auth", "Per-endpoint Basic Auth", "endpoint credentials in config", "1. Capture Authorization headers", "rfid/anpr/invalid/etc", "Each endpoint uses configured username/password", "P1", "Positive", "Manual"],
    # ------------------------------------------------------------------ FSM
    ["TC-FSM-001", "FSM", "Happy", "IDLE → POSITIONING → WEIGHT → RFID_READ", "Unit / demo", "1. ENTRY 2. WB 3. WEIGHT_OK", "Events", "States advance correctly", "P0", "Positive", "Automated"],
    ["TC-FSM-002", "FSM", "Invalid", "Invalid transition ignored", "IDLE", "1. Trigger WB_SENSOR without ENTRY", "bad event", "Stay IDLE; no crash", "P2", "Negative", "Automated"],
    ["TC-FSM-003", "FSM", "Reset", "RESET from EXIT_GRANTED → IDLE", "EXIT_GRANTED", "1. RESET / force_reset", "Event.RESET", "IDLE; txn cleared", "P1", "Positive", "Manual"],
    # ------------------------------------------------------------------ Settings / Config
    ["TC-CFG-001", "Config", "Load", "Loads checkpoint-config or local iot_configuration.json", "Config present", "1. Start app / load_settings", "tare_wb", "checkpoint_type tare_wb; digitizer OCI ANPR URLs loaded", "P1", "Positive", "Automated"],
    ["TC-CFG-002", "Config", "DEVICE_IP", "DEVICE_IP from .env in payloads", ".env DEVICE_IP set", "1. Capture OCI/ANPR", "192.168.x.x", "device_ip matches", "P1", "Positive", "Manual"],
    ["TC-CFG-003", "Config", "Camera", "top_camera_rtsp_url from camera.top", "iot camera.top.rtsp_url", "1. load_settings", "rtsp://...", "settings.top_camera_rtsp_url set", "P1", "Positive", "Manual"],
    ["TC-CFG-004", "Config", "Min weight", "min_weight_kg default 5000", "Default settings", "1. Weight boundary", "5000 / 5001", "≤5000 fail; >5000 RFID start", "P1", "Positive", "Manual"],
    ["TC-CFG-005", "Config", "wb_type", "Unidirectional vs bidirectional behavior", "Switch wb_type in JSON", "1. Restart 2. Exit sensor while IDLE", "uni vs bi", "Uni ignores; bi starts ENTRY_B", "P0", "Positive", "Automated"],
    # ------------------------------------------------------------------ Voice / Display
    ["TC-VOC-001", "Voice", "Weight", "Announce tare weight only (no truck VNO)", "Final weight OK", "1. Listen after weight", "weight kg", "tare_final_weight + ton/kg; no vehicle_number clips", "P1", "Positive", "Manual"],
    ["TC-VOC-002", "Voice", "Forward", "MOVE FORWARD every 5s while waiting", "POSITIONING or EXIT_GRANTED", "1. Listen", "forward.wav", "Repeated ~5s until state leaves", "P2", "Positive", "Manual"],
    ["TC-VOC-003", "Voice", "Gate", "Voice off when enabled/validated false", "voice.enabled false", "1. Run cycle", "config", "No WAV playback", "P2", "Positive", "Manual"],
    ["TC-DSP-001", "Display", "Messages", "MOVE FORWARD / WEIGHING / EXIT messages", "MQTT or console display", "1. Run cycle", "MSG_* constants", "Display shows correct phase text", "P1", "Positive", "Manual"],
    # ------------------------------------------------------------------ E2E
    ["TC-E2E-001", "E2E", "Happy uni", "Full uni path ANPR=1 to IDLE", "Hardware+digitizer+OCI+ANPR+cameras", "1. Entry 2. WB weigh>5t 3. RFID 4. ANPR1 5. weight_details 6. Exit sensor", "Valid truck", "Top photo; boom-close; exit open; after exit+10s boom closed IDLE", "P0", "Positive", "Manual"],
    ["TC-E2E-002", "E2E", "Happy manual", "ANPR=0 then vehicleStatus=1", "Same stack", "1. ANPR 0 2. Wait status_check 1 3. Complete weight/exit", "vehicleStatus 0 then 1", "5s polls; continue after 1; exit IDLE", "P0", "Positive", "Manual"],
    ["TC-E2E-003", "E2E", "ANPR 2", "ANPR=2 then vehicleStatus=1 completes weight", "RFID valid", "1. ANPR 2 2. status_check vehicleStatus 1 3. Complete weight/exit", "anpr_status 2 then vehicleStatus 1", "status_check loop; then weight_details like status 1; exit IDLE", "P0", "Positive", "Manual"],
    ["TC-E2E-004", "E2E", "Low weight", "Abort when weight ≤5t", "Entry+WB", "1. Weight 4t", "4000 kg", "IDLE; RFID never contacted", "P0", "Negative", "Manual"],
    ["TC-E2E-005", "E2E", "Bidirectional A", "ENTRY_A full cycle", "wb_type bi", "1. Entry approach → weigh → RFID → ANPR1 → exit sensor", "ENTRY_A", "entry_a RFID used; exit completes", "P0", "Positive", "Manual"],
    ["TC-E2E-006", "E2E", "Bidirectional B", "ENTRY_B full cycle", "wb_type bi", "1. Exit approach → weigh → RFID → ANPR1 → entry sensor", "ENTRY_B", "entry_b RFID used; entry completes", "P0", "Positive", "Manual"],
    # ------------------------------------------------------------------ Robustness
    ["TC-ROB-001", "Robustness", "Busy", "Second RFID ignored while validating", "RFID cycle running", "1. Second /rfid_data", "two tags", "Workflow busy / ignored; first completes", "P1", "Negative", "Manual"],
    ["TC-ROB-002", "Robustness", "OCI timeout", "OCI timeout safe", "Slow OCI", "1. RFID validate timeout", ">15s", "Error handled; no crash; safe reset", "P2", "Negative", "Manual"],
    ["TC-ROB-003", "Robustness", "Modbus noise", "Transaction-id mismatch does not crash", "Shared Modbus board noise", "1. Run sensor poll under noise", "pymodbus skipping", "App continues; resync after failures; noise filtered in logs", "P2", "Negative", "Manual"],
    ["TC-ROB-004", "Robustness", "Digitizer down", "Digitizer unreachable", "WEIGHT_CAPTURE", "1. Digitizer host down", "connection error", "Fail path; IDLE; no RFID start", "P1", "Negative", "Manual"],
    # ------------------------------------------------------------------ Unit coverage map
    ["TC-UT-001", "Unit", "test_anpr_flow", "Payload builders + ANPR branches", "unittest", "python -m unittest tests.test_anpr_flow", "mocks", "All ANPR/status_check/boom/weight payload tests pass", "P1", "Positive", "Automated"],
    ["TC-UT-002", "Unit", "test_bidirectional_flow", "Bi sensor + RFID sequencing", "unittest", "python -m unittest tests.test_bidirectional_flow", "mocks", "ENTRY_A/B selection; RFID after weight; stop on tag; boom delay", "P1", "Positive", "Automated"],
    ["TC-UT-003", "Unit", "test_top_camera", "Top photo naming + capture stub", "unittest", "python -m unittest tests.test_top_camera", "mocks", "Filename + RTSP capture wiring pass", "P1", "Positive", "Automated"],
    ["TC-UT-004", "Unit", "test_smoke", "FSM + settings + demo weight", "unittest", "python -m unittest tests.test_smoke", "local", "Smoke suite pass", "P1", "Positive", "Automated"],
    ["TC-UT-005", "Unit", "Full suite", "Discover all tests", "venv + gmdc_common", "python -m unittest discover -s tests -v", "TareWb-App", "All tests OK", "P0", "Positive", "Automated"],
]


def _write_csv() -> None:
    DOCS.mkdir(parents=True, exist_ok=True)
    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(HEADERS)
        writer.writerows(ROWS)


def _write_xlsx() -> None:
    DOCS.mkdir(parents=True, exist_ok=True)
    wb = Workbook()

    # --- Sheet 1: All cases ---
    ws = wb.active
    ws.title = "Test Cases"
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)
    wrap = Alignment(wrap_text=True, vertical="top")

    for col, name in enumerate(HEADERS, 1):
        cell = ws.cell(1, col, name)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    p0_fill = PatternFill("solid", fgColor="FCE4D6")
    auto_fill = PatternFill("solid", fgColor="E2EFDA")

    for r_idx, row in enumerate(ROWS, 2):
        for c_idx, value in enumerate(row, 1):
            cell = ws.cell(r_idx, c_idx, value)
            cell.alignment = wrap
        if row[8] == "P0":
            for c_idx in range(1, len(HEADERS) + 1):
                ws.cell(r_idx, c_idx).fill = p0_fill
        if row[10] == "Automated":
            ws.cell(r_idx, 11).fill = auto_fill
            if row[8] == "P0":
                # Keep P0 tint but mark Automation column green
                ws.cell(r_idx, 11).fill = auto_fill

    widths = [12, 14, 14, 42, 28, 40, 28, 48, 10, 10, 12]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(HEADERS))}{len(ROWS) + 1}"

    # --- Sheet 2: Summary by module ---
    summary = wb.create_sheet("Summary")
    summary.append(["Module", "Count", "P0", "P1", "P2", "P3", "Automated", "Manual"])
    for col in range(1, 9):
        cell = summary.cell(1, col)
        cell.fill = header_fill
        cell.font = header_font

    modules: dict[str, dict[str, int]] = {}
    for row in ROWS:
        mod = row[1]
        bucket = modules.setdefault(
            mod,
            {"Count": 0, "P0": 0, "P1": 0, "P2": 0, "P3": 0, "Automated": 0, "Manual": 0},
        )
        bucket["Count"] += 1
        pri = row[8]
        if pri in bucket:
            bucket[pri] += 1
        auto = row[10]
        if auto == "Automated":
            bucket["Automated"] += 1
        else:
            bucket["Manual"] += 1

    for mod in sorted(modules):
        b = modules[mod]
        summary.append(
            [
                mod,
                b["Count"],
                b["P0"],
                b["P1"],
                b["P2"],
                b["P3"],
                b["Automated"],
                b["Manual"],
            ]
        )
    summary.append(
        [
            "TOTAL",
            len(ROWS),
            sum(1 for r in ROWS if r[8] == "P0"),
            sum(1 for r in ROWS if r[8] == "P1"),
            sum(1 for r in ROWS if r[8] == "P2"),
            sum(1 for r in ROWS if r[8] == "P3"),
            sum(1 for r in ROWS if r[10] == "Automated"),
            sum(1 for r in ROWS if r[10] != "Automated"),
        ]
    )
    for i, w in enumerate([18, 10, 8, 8, 8, 8, 12, 10], 1):
        summary.column_dimensions[get_column_letter(i)].width = w

    # --- Sheet 3: Flow reference ---
    flow = wb.create_sheet("Flow Reference")
    flow["A1"] = "Tare WB flow reference"
    flow["A1"].font = Font(bold=True, size=14)
    lines = [
        "",
        "IDLE (entry green/open, exit red/closed)",
        "  → Entry (or Exit if bi) occupied → VEHICLE_POSITIONING (RFID NOT started)",
        "  → WB occupied → WEIGHT_CAPTURE (entry closed)",
        "  → Digitizer weight > 5 t → RFID login/mode/start → RFID_READ",
        "  → Tag received → RFID stop immediately → OCI validate",
        "  → ANPR detect (payload: vehicle_number, rfid, token, device_ip)",
        "",
        "anpr_status=1: top photo → invalid-truck → final weight → weight-details → boom-close(truck_details) → EXIT",
        "anpr_status=0: top photo → invalid-truck → status_check every 5s until vehicleStatus=1 → same weight path",
        "anpr_status=2: same as status 0 (status_check loop); vehicleStatus=1 continues like status 1",
        "",
        "Crossing: EXIT sensor (ENTRY_A) or ENTRY sensor (ENTRY_B) → IDLE; exit boom close after 10s",
        "",
        f"Generated cases: {len(ROWS)}",
        "Regenerate: python tests/generate_test_cases_excel.py",
    ]
    for i, line in enumerate(lines, 2):
        flow.cell(i, 1, line)
    flow.column_dimensions["A"].width = 110

    wb.save(OUT_XLSX)


def main() -> None:
    _write_csv()
    _write_xlsx()
    print(f"Wrote {len(ROWS)} test cases")
    print(f"  Excel: {OUT_XLSX}")
    print(f"  CSV:   {OUT_CSV}")


if __name__ == "__main__":
    main()
