# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for GMDC Digitizer (serial_ui.py)
#
# Build (onedir, recommended for PySide6):
#   pyinstaller serial_ui.spec
#
# Output: dist/GMDCDigitizer/GMDCDigitizer.exe

block_cipher = None

a = Analysis(
    ["serial_ui.py"],
    pathex=[],
    binaries=[],
    datas=[("app_icon.ico", ".")],
    hiddenimports=[
        "serial.tools.list_ports",
        "index_engine",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="GMDCDigitizer",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="app_icon.ico",
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="GMDCDigitizer",
)
